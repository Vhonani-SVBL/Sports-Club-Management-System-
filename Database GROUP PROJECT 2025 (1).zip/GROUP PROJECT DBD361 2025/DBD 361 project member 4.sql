-- 1. Create Database
CREATE DATABASE TygersSportsClub;
GO

USE TygersSportsClub;
GO

-- 2. Tables

-- Coaches
CREATE TABLE Coaches (
    CoachID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    Specialty NVARCHAR(100) NOT NULL,
    Phone NVARCHAR(20) NOT NULL
);

-- Teams
CREATE TABLE Teams (
    TeamID INT PRIMARY KEY IDENTITY(1,1),
    TeamName NVARCHAR(100) NOT NULL UNIQUE,
    CoachID INT NULL,
    CONSTRAINT FK_Teams_Coaches FOREIGN KEY (CoachID) REFERENCES Coaches(CoachID)
);

-- Members
CREATE TABLE Members (
    MemberID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    DateOfBirth DATE NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    Phone NVARCHAR(20) NOT NULL,
    JoinDate DATE NOT NULL CHECK (JoinDate <= GETDATE()),
    TeamID INT NULL,
    CONSTRAINT FK_Members_Teams FOREIGN KEY (TeamID) REFERENCES Teams(TeamID)
);

-- Sessions
CREATE TABLE Sessions (
    SessionID INT PRIMARY KEY IDENTITY(1,1),
    SessionDate DATE NOT NULL,
    Time TIME NOT NULL,
    SportType NVARCHAR(50) NOT NULL,
    Location NVARCHAR(100) NOT NULL,
    CoachID INT NOT NULL,
    CONSTRAINT FK_Sessions_Coaches FOREIGN KEY (CoachID) REFERENCES Coaches(CoachID)
);

-- Payments
CREATE TABLE Payments (
    PaymentID INT PRIMARY KEY IDENTITY(1,1),
    MemberID INT NOT NULL,
    Amount DECIMAL(10,2) NOT NULL CHECK (Amount > 0),
    PaymentDate DATE NOT NULL,
    PaymentType NVARCHAR(20) NOT NULL,
    CONSTRAINT FK_Payments_Members FOREIGN KEY (MemberID) REFERENCES Members(MemberID)
);

-- Registrations (Bridge Table)
CREATE TABLE Registrations (
    RegistrationID INT PRIMARY KEY IDENTITY(1,1),
    MemberID INT NOT NULL,
    SessionID INT NOT NULL,
    CONSTRAINT FK_Registrations_Members FOREIGN KEY (MemberID) REFERENCES Members(MemberID),
    CONSTRAINT FK_Registrations_Sessions FOREIGN KEY (SessionID) REFERENCES Sessions(SessionID)
);

-- 3. Indexes
CREATE NONCLUSTERED INDEX IX_Members_Name ON Members(FirstName, LastName);
CREATE NONCLUSTERED INDEX IX_Sessions_SessionDate ON Sessions(SessionDate);

-- 4. Views

-- vw_MemberDetails
CREATE VIEW vw_MemberDetails AS
SELECT 
    m.MemberID, m.FirstName, m.LastName, m.Email, m.Phone, m.JoinDate,
    t.TeamName, 
    c.FirstName AS CoachFirstName, c.LastName AS CoachLastName, c.Specialty
FROM Members m
LEFT JOIN Teams t ON m.TeamID = t.TeamID
LEFT JOIN Coaches c ON t.CoachID = c.CoachID;

-- vw_UpcomingSessions
CREATE VIEW vw_UpcomingSessions AS
SELECT 
    s.SessionID, s.SessionDate, s.Time, s.SportType, s.Location,
    c.FirstName AS CoachFirstName, c.LastName AS CoachLastName
FROM Sessions s
INNER JOIN Coaches c ON s.CoachID = c.CoachID
WHERE s.SessionDate >= CAST(GETDATE() AS DATE);

-- vw_PaymentSummary
CREATE VIEW vw_PaymentSummary AS
SELECT 
    m.MemberID, m.FirstName, m.LastName,
    SUM(p.Amount) AS TotalPaid,
    MAX(p.PaymentDate) AS LastPaymentDate
FROM Members m
LEFT JOIN Payments p ON m.MemberID = p.MemberID
GROUP BY m.MemberID, m.FirstName, m.LastName;

-- 5. Stored Procedures

-- sp_AddMember
CREATE PROCEDURE sp_AddMember
    @FirstName NVARCHAR(50),
    @LastName NVARCHAR(50),
    @DateOfBirth DATE,
    @Email NVARCHAR(100),
    @Phone NVARCHAR(20),
    @JoinDate DATE,
    @TeamID INT = NULL
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Members WHERE Email = @Email)
    BEGIN
        RAISERROR('Email already exists.', 16, 1);
        RETURN;
    END
    IF @JoinDate > GETDATE()
    BEGIN
        RAISERROR('JoinDate cannot be in the future.', 16, 1);
        RETURN;
    END
    INSERT INTO Members (FirstName, LastName, DateOfBirth, Email, Phone, JoinDate, TeamID)
    VALUES (@FirstName, @LastName, @DateOfBirth, @Email, @Phone, @JoinDate, @TeamID);
END;

-- sp_ScheduleSession
CREATE PROCEDURE sp_ScheduleSession
    @SessionDate DATE,
    @Time TIME,
    @SportType NVARCHAR(50),
    @Location NVARCHAR(100),
    @CoachID INT
AS
BEGIN
    IF EXISTS (
        SELECT 1 FROM Sessions 
        WHERE CoachID = @CoachID AND SessionDate = @SessionDate AND Time = @Time
    )
    BEGIN
        RAISERROR('Coach is already scheduled for another session at this time.', 16, 1);
        RETURN;
    END
    INSERT INTO Sessions (SessionDate, Time, SportType, Location, CoachID)
    VALUES (@SessionDate, @Time, @SportType, @Location, @CoachID);
END;

-- sp_ProcessPayment
CREATE PROCEDURE sp_ProcessPayment
    @MemberID INT,
    @Amount DECIMAL(10,2),
    @PaymentDate DATE,
    @PaymentType NVARCHAR(20)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Members WHERE MemberID = @MemberID)
    BEGIN
        RAISERROR('Member does not exist.', 16, 1);
        RETURN;
    END
    IF @Amount <= 0
    BEGIN
        RAISERROR('Amount must be greater than zero.', 16, 1);
        RETURN;
    END
    INSERT INTO Payments (MemberID, Amount, PaymentDate, PaymentType)
    VALUES (@MemberID, @Amount, @PaymentDate, @PaymentType);
END;

-- sp_GetMemberSessions
CREATE PROCEDURE sp_GetMemberSessions
    @MemberID INT
AS
BEGIN
    SELECT s.*
    FROM Registrations r
    INNER JOIN Sessions s ON r.SessionID = s.SessionID
    WHERE r.MemberID = @MemberID;
END;

-- 6. Trigger

-- trg_AfterPayment
CREATE TABLE PaymentAudit (
    AuditID INT PRIMARY KEY IDENTITY(1,1),
    PaymentID INT,
    MemberID INT,
    Amount DECIMAL(10,2),
    PaymentDate DATE,
    PaymentType NVARCHAR(20),
    AuditDate DATETIME DEFAULT GETDATE()
);

CREATE TRIGGER trg_AfterPayment
ON Payments
AFTER INSERT
AS
BEGIN
    INSERT INTO PaymentAudit (PaymentID, MemberID, Amount, PaymentDate, PaymentType)
    SELECT PaymentID, MemberID, Amount, PaymentDate, PaymentType
    FROM inserted;
END;

-- 7. Security Roles

-- Administrator: Full access
CREATE ROLE Administrator;
-- Coach: Read/write access to Sessions and Teams
CREATE ROLE Coach;
-- Member: Read-only access to their own records
CREATE ROLE Member;

-- Grant permissions (example, adjust as needed)
GRANT SELECT, INSERT, UPDATE, DELETE ON Members TO Administrator;
GRANT SELECT, INSERT, UPDATE, DELETE ON Teams TO Administrator;
GRANT SELECT, INSERT, UPDATE, DELETE ON Coaches TO Administrator;
GRANT SELECT, INSERT, UPDATE, DELETE ON Sessions TO Administrator;
GRANT SELECT, INSERT, UPDATE, DELETE ON Payments TO Administrator;
GRANT SELECT, INSERT, UPDATE, DELETE ON Registrations TO Administrator;

GRANT SELECT, INSERT, UPDATE ON Sessions TO Coach;
GRANT SELECT, INSERT, UPDATE ON Teams TO Coach;

GRANT SELECT ON vw_MemberDetails TO Member;
GRANT SELECT ON vw_UpcomingSessions TO Member;
GRANT SELECT ON vw_PaymentSummary TO Member;

-- 8. Testing (Sample Inserts)
-- Add sample data for testing
INSERT INTO Coaches (FirstName, LastName, Specialty, Phone) VALUES ('John', 'Smith', 'Football', '1234567890');
INSERT INTO Teams (TeamName, CoachID) VALUES ('Tigers', 1);
EXEC sp_AddMember 'Alice', 'Brown', '2002-05-10', 'alice.brown@email.com', '5551234567', '2023-09-01', 1;
EXEC sp_ScheduleSession '2025-10-10', '15:00', 'Football', 'Main Field', 1;
EXEC sp_ProcessPayment 1, 100.00, '2025-10-01', 'Cash';

-- 9. Backup
-- Run this in SSMS after testing
-- BACKUP DATABASE TygersSportsClub TO DISK = 'C:\Backups\TygersSportsClub_Full.bak' WITH FORMAT, INIT;

-- End of script